"""Unit tests for inbox/widgets.py helpers."""
from __future__ import annotations

from datetime import UTC, datetime, timedelta

from triage_cli.inbox.widgets import _CONFIDENCE_STYLE, _ROW_STYLE, _relative_time


def _now() -> datetime:
    return datetime(2026, 5, 9, 12, 0, 0, tzinfo=UTC)


def test_relative_time_just_now() -> None:
    assert _relative_time(_now() - timedelta(seconds=30), now=_now()) == "just now"


def test_relative_time_boundary_just_now_to_minutes() -> None:
    # 1m59s → "just now"; 2m00s → "Xm ago"
    assert _relative_time(_now() - timedelta(seconds=119), now=_now()) == "just now"
    assert _relative_time(_now() - timedelta(seconds=120), now=_now()) == "2m ago"


def test_relative_time_minutes() -> None:
    assert _relative_time(_now() - timedelta(minutes=14), now=_now()) == "14m ago"


def test_relative_time_hours() -> None:
    assert _relative_time(_now() - timedelta(hours=3), now=_now()) == "3h ago"


def test_relative_time_days() -> None:
    assert _relative_time(_now() - timedelta(days=2), now=_now()) == "2d ago"


def test_confidence_style_high() -> None:
    assert _CONFIDENCE_STYLE["high"] == "[bold green]high[/]"


def test_confidence_style_medium() -> None:
    assert _CONFIDENCE_STYLE["medium"] == "[yellow]med[/]"


def test_confidence_style_low() -> None:
    assert _CONFIDENCE_STYLE["low"] == "[red]low[/]"


def test_confidence_style_unknown_falls_through() -> None:
    assert _CONFIDENCE_STYLE.get("unexpected", "unexpected") == "unexpected"


def test_row_style_failed_is_dark_red() -> None:
    assert _ROW_STYLE["failed"] == "on dark_red"


def test_row_style_triaging_is_dark_goldenrod() -> None:
    assert _ROW_STYLE["triaging"] == "on dark_goldenrod"


def test_row_style_triaged_is_none() -> None:
    assert _ROW_STYLE["triaged"] is None


def test_row_style_queued_is_none() -> None:
    assert _ROW_STYLE["queued"] is None


def test_relative_time_naive_datetime_treated_as_utc() -> None:
    now = datetime(2026, 5, 9, 12, 0, 0, tzinfo=UTC)
    naive_dt = datetime(2026, 5, 9, 11, 50, 0)  # no tzinfo, 10 minutes before now
    assert _relative_time(naive_dt, now=now) == "10m ago"
