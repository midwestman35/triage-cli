"""Read-only Zendesk client for fetching a ticket and its full comment thread."""
from __future__ import annotations

import hashlib
import logging
import os
from datetime import datetime
from pathlib import Path
from types import TracebackType
from typing import Any

import httpx

from triage_cli.models import AttachmentEvidence, Comment, Ticket, TicketSummary

logger = logging.getLogger(__name__)

_USER_AGENT = "triage-cli/0.1"
_PAGE_SIZE = 100
_MAX_PAGES = 1000  # 100k comments at page[size]=100 - far past any real ticket


class AttachmentTooLargeError(Exception):
    """Raised when a Zendesk attachment exceeds the size cap."""


class ZendeskClient:
    """Read-only Zendesk client for fetching tickets and their comment thread."""

    def __init__(
        self,
        subdomain: str,
        email: str,
        api_token: str,
        timeout: float = 15.0,
    ) -> None:
        """Construct a client bound to a Zendesk subdomain with basic-auth credentials."""
        self._base_url = f"https://{subdomain}.zendesk.com/api/v2"
        # Zendesk basic-auth: username is "{email}/token", password is the api token.
        self._client = httpx.Client(
            auth=(f"{email}/token", api_token),
            timeout=timeout,
            headers={"User-Agent": _USER_AGENT, "Accept": "application/json"},
        )

    @classmethod
    def from_env(cls) -> ZendeskClient:
        """Construct from ZENDESK_SUBDOMAIN, ZENDESK_EMAIL, ZENDESK_API_TOKEN env vars."""
        required = ("ZENDESK_SUBDOMAIN", "ZENDESK_EMAIL", "ZENDESK_API_TOKEN")
        values = {name: os.environ.get(name) for name in required}
        missing = [name for name, value in values.items() if not value]
        if missing:
            raise RuntimeError(
                f"Missing required environment variables: {', '.join(missing)}"
            )
        return cls(
            subdomain=values["ZENDESK_SUBDOMAIN"],  # type: ignore[arg-type]
            email=values["ZENDESK_EMAIL"],  # type: ignore[arg-type]
            api_token=values["ZENDESK_API_TOKEN"],  # type: ignore[arg-type]
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> ZendeskClient:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def get_ticket(self, ticket_id: int) -> Ticket:
        """Fetch a Zendesk ticket plus its full comment thread and return a Ticket model."""
        payload = self._get(
            f"/tickets/{ticket_id}.json",
            params={"include": "users,organizations"},
            ticket_id=ticket_id,
        )
        ticket_obj = payload.get("ticket") or {}
        users_by_id = {u["id"]: u for u in payload.get("users", []) if "id" in u}
        orgs_by_id = {o["id"]: o for o in payload.get("organizations", []) if "id" in o}

        org_id = ticket_obj.get("organization_id")
        if org_id is None:
            requester = users_by_id.get(ticket_obj.get("requester_id"))
            if requester:
                org_id = requester.get("organization_id")
        org = orgs_by_id.get(org_id) if org_id is not None else None
        requester_org = org.get("name") if org else None

        requester_id = ticket_obj.get("requester_id")
        requester_user = users_by_id.get(requester_id) if requester_id else None
        requester_email = requester_user.get("email") if requester_user else None

        return Ticket(
            id=int(ticket_obj["id"]),
            subject=ticket_obj.get("subject") or "",
            description=ticket_obj.get("description") or "",
            requester_org=requester_org,
            requester_email=requester_email,
            tags=list(ticket_obj.get("tags") or []),
            created_at=_parse_iso(ticket_obj["created_at"]),
            updated_at=_parse_iso(ticket_obj["updated_at"]),
            comments=self._fetch_comments(ticket_id),
        )

    def list_view_ticket_ids(self, view_id: int) -> list[int]:
        """Return ticket IDs in the given Zendesk view, in the order returned.

        Paginates via cursor (meta.has_more + links.next) with legacy next_page
        fallback. Raises RuntimeError on transport failure or non-2xx status;
        a 404 surfaces a view-flavored message.
        """
        path: str | None = f"/views/{view_id}/tickets.json"
        params: dict[str, Any] | None = {"page[size]": _PAGE_SIZE}
        ids: list[int] = []

        for _ in range(_MAX_PAGES):
            if path is None:
                break
            try:
                payload = self._get(path, params=params, ticket_id=view_id)
            except RuntimeError as e:
                if str(e).startswith(f"Ticket {view_id} not found"):
                    raise RuntimeError(f"View {view_id} not found") from e
                raise
            for t in payload.get("tickets") or []:
                if "id" in t:
                    ids.append(int(t["id"]))

            meta = payload.get("meta") or {}
            links = payload.get("links") or {}
            if meta.get("has_more") and links.get("next"):
                path = links["next"]
            else:
                path = payload.get("next_page")
            params = None
        else:
            raise RuntimeError(
                f"Zendesk view pagination exceeded {_MAX_PAGES} pages - possible loop"
            )
        return ids

    def list_my_ticket_ids(self) -> list[int]:
        """Return IDs of open tickets assigned to the authenticated user.

        Fetches the current user via /users/me.json, then pages through the
        search API with ``assignee_id:<user_id> status<closed type:ticket``.
        Closed tickets and CC'd tickets are excluded.
        """
        me = self._get("/users/me.json", params=None, ticket_id=0)
        user_id = (me.get("user") or {}).get("id")
        if user_id is None:
            raise RuntimeError("Could not determine current Zendesk user ID from /users/me.json")

        path: str | None = "/search.json"
        params: dict[str, Any] | None = {
            "query": f"assignee_id:{user_id} status<closed type:ticket",
            "sort_by": "created_at",
            "sort_order": "desc",
            "page[size]": _PAGE_SIZE,
        }
        ids: list[int] = []

        for _ in range(_MAX_PAGES):
            if path is None:
                break
            payload = self._get(path, params=params, ticket_id=user_id)
            for result in payload.get("results") or []:
                if "id" in result:
                    ids.append(int(result["id"]))

            meta = payload.get("meta") or {}
            links = payload.get("links") or {}
            if meta.get("has_more") and links.get("next"):
                path = links["next"]
            else:
                path = payload.get("next_page")
            params = None
        else:
            raise RuntimeError("Zendesk assigned-tickets search pagination exceeded limit")

        return ids

    def _fetch_comments(self, ticket_id: int) -> list[Comment]:
        """Page through /comments.json (with sideloaded users) and return Comment models."""
        path: str | None = f"/tickets/{ticket_id}/comments.json"
        params: dict[str, Any] | None = {
            "include": "users",
            "page[size]": _PAGE_SIZE,
            "sort": "created_at",
        }
        users_by_id: dict[int, dict[str, Any]] = {}
        raw: list[dict[str, Any]] = []

        for _ in range(_MAX_PAGES):
            if path is None:
                break
            payload = self._get(path, params=params, ticket_id=ticket_id)
            for u in payload.get("users") or []:
                if "id" in u:
                    users_by_id[u["id"]] = u
            raw.extend(payload.get("comments") or [])

            # Cursor pagination (newer): meta.has_more + links.next. Legacy: next_page.
            meta = payload.get("meta") or {}
            links = payload.get("links") or {}
            if meta.get("has_more") and links.get("next"):
                path = links["next"]
            else:
                path = payload.get("next_page")
            params = None  # the follow-up URL already carries query params
        else:
            raise RuntimeError(
                f"Zendesk comments pagination exceeded {_MAX_PAGES} pages - possible loop"
            )

        comments = [_to_comment(rc, users_by_id) for rc in raw]
        comments.sort(key=lambda c: c.created_at)
        return comments

    def _get(
        self,
        path: str,
        params: dict[str, Any] | None,
        ticket_id: int,
    ) -> dict[str, Any]:
        """Issue a GET (relative or absolute URL) and map non-2xx responses to RuntimeError."""
        url = path if path.startswith("http") else f"{self._base_url}{path}"
        logger.debug("GET %s", url)
        try:
            resp = self._client.get(url, params=params)
        except httpx.HTTPError as e:
            raise RuntimeError(f"Zendesk request failed: {e}") from e

        if resp.is_success:
            try:
                return resp.json()
            except ValueError as e:
                raise RuntimeError(
                    f"Zendesk returned non-JSON response: {e}"
                ) from e

        status = resp.status_code
        if status == 404:
            raise RuntimeError(f"Ticket {ticket_id} not found")
        if status in (401, 403):
            raise RuntimeError(
                "Zendesk auth failed - check ZENDESK_EMAIL and ZENDESK_API_TOKEN"
            )
        if status == 429:
            retry_after = resp.headers.get("Retry-After", "unknown")
            raise RuntimeError(f"Zendesk rate-limited; retry after {retry_after} seconds")
        raise RuntimeError(f"Zendesk error {status}: {(resp.text or '')[:200]}")

    def fetch_customer_history(
        self,
        requester_email: str,
        *,
        limit: int = 10,
    ) -> list[TicketSummary]:
        """Return the last `limit` tickets for a requester, newest first.

        Never raises — customer history is enrichment, not a pipeline gate.
        Returns an empty list if email is missing or any error occurs.
        """
        if not requester_email:
            return []

        try:
            data = self._get(
                "/search.json",
                params={
                    "query": f"requester:{requester_email} type:ticket",
                    "sort_by": "updated_at",
                    "sort_order": "desc",
                    "per_page": limit,
                },
                ticket_id=0,
            )
            results = data.get("results", [])[:limit]
            return [
                TicketSummary(
                    id=r["id"],
                    subject=r.get("subject", "(no subject)"),
                    status=r.get("status", "unknown"),
                    created_at=_parse_iso(r["created_at"]),
                    updated_at=_parse_iso(r["updated_at"]),
                )
                for r in results
            ]
        except Exception:
            logger.warning(
                "fetch_customer_history failed for %s", requester_email, exc_info=True
            )
            return []

    def download_attachment(
        self,
        url: str,
        dest_path: Path,
        *,
        max_bytes: int = 150 * 1024 * 1024,
    ) -> tuple[int, str]:
        """Stream-download a Zendesk attachment to disk.

        Returns (bytes_written, sha256_hex). Aborts mid-stream and unlinks the
        partial file if max_bytes is exceeded. Reuses the authenticated client.
        """
        partial = dest_path.with_suffix(dest_path.suffix + ".partial")
        hasher = hashlib.sha256()
        bytes_written = 0
        try:
            with self._client.stream("GET", url, follow_redirects=True) as resp:
                if resp.status_code == 404:
                    raise RuntimeError(f"Attachment not found at {url}")
                if resp.status_code in (401, 403):
                    raise RuntimeError(
                        "Zendesk auth failed during attachment download"
                    )
                if resp.status_code == 429:
                    retry_after = resp.headers.get("Retry-After", "unknown")
                    raise RuntimeError(
                        f"Zendesk rate-limited; retry after {retry_after} seconds"
                    )
                if not resp.is_success:
                    raise RuntimeError(
                        f"Zendesk error {resp.status_code} downloading attachment"
                    )

                # Pre-flight Content-Length check.
                cl = resp.headers.get("Content-Length")
                if cl is not None and int(cl) > max_bytes:
                    raise AttachmentTooLargeError(
                        f"attachment is {cl} bytes; cap is {max_bytes} bytes"
                    )

                with partial.open("wb") as f:
                    for chunk in resp.iter_bytes():
                        if bytes_written + len(chunk) > max_bytes:
                            f.close()
                            partial.unlink(missing_ok=True)
                            raise AttachmentTooLargeError(
                                f"attachment exceeded cap {max_bytes} bytes mid-stream"
                            )
                        f.write(chunk)
                        hasher.update(chunk)
                        bytes_written += len(chunk)
        except httpx.HTTPError as e:
            partial.unlink(missing_ok=True)
            raise RuntimeError(f"Attachment download failed: {e}") from e
        except BaseException:
            partial.unlink(missing_ok=True)
            raise

        partial.replace(dest_path)
        return bytes_written, hasher.hexdigest()


def _to_comment(rc: dict[str, Any], users_by_id: dict[int, dict[str, Any]]) -> Comment:
    """Map a raw Zendesk comment dict to a Comment model."""
    author = _resolve_author(rc.get("author_id"), users_by_id)
    body = rc.get("plain_body") or rc.get("body") or ""
    return Comment(
        author=author,
        body=body,
        created_at=_parse_iso(rc["created_at"]),
        is_public=bool(rc.get("public", False)),
        attachments=_attachments_from_raw(rc.get("attachments") or []),
    )


def _attachments_from_raw(raw_attachments: list[dict[str, Any]]) -> list[AttachmentEvidence]:
    """Map Zendesk attachment metadata, including the pre-signed content_url.

    The url is kept in-memory only; the render layer strips it before
    serializing to disk (see triage_cli.render.save_note).
    """
    attachments: list[AttachmentEvidence] = []
    for raw in raw_attachments:
        filename = raw.get("file_name") or raw.get("filename") or raw.get("name")
        if not filename:
            continue
        size = raw.get("size") if raw.get("size") is not None else raw.get("size_bytes")
        attachments.append(
            AttachmentEvidence(
                filename=str(filename),
                content_type=(
                    str(raw["content_type"]) if raw.get("content_type") is not None else None
                ),
                size_bytes=int(size) if size is not None else None,
                content_url=(
                    str(raw["content_url"]) if raw.get("content_url") is not None else None
                ),
            )
        )
    return attachments


def _resolve_author(
    author_id: int | None, users_by_id: dict[int, dict[str, Any]]
) -> str:
    """Resolve a Zendesk user id to a display string. Prefer name, then email, then user-{id}."""
    if author_id is None:
        return "user-unknown"
    user = users_by_id.get(author_id)
    if user:
        if user.get("name"):
            return str(user["name"])
        if user.get("email"):
            return str(user["email"])
    return f"user-{author_id}"


def _parse_iso(value: str) -> datetime:
    """Parse an ISO 8601 timestamp from Zendesk (handles trailing Z)."""
    return datetime.fromisoformat(value.replace("Z", "+00:00"))
